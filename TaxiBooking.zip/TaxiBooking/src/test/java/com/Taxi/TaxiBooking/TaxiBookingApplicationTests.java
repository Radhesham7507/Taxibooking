package com.Taxi.TaxiBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxiBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
