package com.Taxi.TaxiBooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxiBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaxiBookingApplication.class, args);
		System.err.println("Runingg.......");
	}

}
